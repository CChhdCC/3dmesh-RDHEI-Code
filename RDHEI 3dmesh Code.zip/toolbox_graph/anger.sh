/Share/apps/matlab/R2016a/bin/matlab  -nodesktop -nosplash -r 'cd /Share/home/D11714020/MSB;main;exit'
